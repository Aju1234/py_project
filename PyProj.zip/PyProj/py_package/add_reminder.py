import os
import time

def add_reminder():
    # print("\a")
    f = "alarm.mp3"
    os.system(f)