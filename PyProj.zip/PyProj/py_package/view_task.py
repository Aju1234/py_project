import os

def view_task(userName):
    viewFilePath = userName + ".txt"
    filepath = os.path.join('C:\\Users\\ajink\\OneDrive\\Desktop\\TYS6\\Python\\PyProj\\UserTasks', viewFilePath)
    f = open(filepath, "r+")
    # lines = f.readlines()
    print(f.read())