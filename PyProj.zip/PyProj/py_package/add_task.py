import os
from py_package import view_task

def getNextId(path):
    f = open(path, "r")
    lines = len(f.readlines())
    if(lines == 0):
        return 1
    return (lines //3) + 1

def add_task(userName):

    taskFileName = userName + ".txt"
    filepath = os.path.join('C:\\Users\\ajink\\OneDrive\\Desktop\\TYS6\\Python\\PyProj\\UserTasks', taskFileName)
    print("Please enter the following details about your task: ")
    taskTitle = input("Enter the task  title: ")
    taskDeadline = input("Enter the deadline for the task: ")

    f = open(filepath, "a+")
    getNewId = getNextId(filepath)
    if(getNewId == 1):
        f.write("Task-1 ID : "+ str(getNewId))
    else:
        f.write("\nTask-" +str(getNewId) +" ID : "+ str(getNewId)) 
    f.write("\nTask-" +str(getNewId) +" Title : " + taskTitle)
    f.write("\nTask-" +str(getNewId) + " Deadline : " + taskDeadline)

    f.close()