from xml.etree.ElementTree import TreeBuilder


import os

def delete_task(userName):
    deleteFilePath = userName + ".txt"
    filepath = os.path.join('C:\\Users\\ajink\\OneDrive\\Desktop\\TYS6\\Python\\PyProj\\UserTasks', deleteFilePath)

    f = open(filepath, "r+")
    # lines = f.readlines()
    print(f.read())

    deleteId = input = ("Enter the ID of the task you want to delete: ")

    with open(filepath, "r+") as input:
        with open("temp.txt", "w") as output:
            # iterate all lines from file
            for line in input:
                # if line starts with substring 'time' then don't write it in temp file
                if not line.strip("\n").startswith("Task-"+deleteId):
                    output.write(line)

# replace file with original name
    os.replace('temp.txt', filepath)